<?php

return [
    'db' => [
        'host' => '177.136.234.91',
        'dbname' => 'soarcondicionado_crm',
        'user' => 'soarcondicionado_cm',
        'pass' => '?*4kqWSh1N0V;+~1',
        'charset' => 'utf8mb4'
    ],
    'app_url' => 'https://crm.soarcondicionadobh.com.br',
    'app_key' => 'OYP6bZVdFg0C28KUEZoVBNiuUhHvPGWfBl05HxfrLBI='
];
