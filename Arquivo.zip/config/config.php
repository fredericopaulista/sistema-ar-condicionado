<?php

return [
    'db' => [
        'host' => '177.136.234.91',
        'dbname' => 'soarcondicionado_crm',
        'user' => 'soarcondicionado_crm',
        'pass' => '?*4kqWSh1N0V;+~1',
        'charset' => 'utf8mb4'
    ],
    'assinafy' => [
        'api_key' => 'IclOq0miwtZ13F3Up8tzVQaZMVotCrj0lxIEt8Nq9ml2Q3FYnTSCxXgLV4GQd4uy',
        'base_url' => 'https://api.assinafy.com.br/v1'
    ],
    'mail' => [
        'host' => 'smtp.gmail.com',
        'port' => 587,
        'user' => 'your-email@gmail.com',
        'pass' => 'your-app-password',
        'from_name' => 'SÓ AR BH - Climatização'
    ],
    'app_url' => 'http://localhost/sistema-ar/public'
];
