<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?? 'Painel' ?> - <?= htmlspecialchars($global_company['company_name'] ?? 'SÓ AR BH') ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-slate-900 text-slate-200">
    <div class="flex min-h-screen">
        <!-- Sidebar -->
        <aside class="w-64 bg-slate-800 border-r border-slate-700 flex-shrink-0">
            <div class="px-6 py-8 border-b border-slate-700/50 mb-4">
                <?php if (!empty($global_company['company_logo'])): ?>
                    <img src="/<?= $global_company['company_logo'] ?>" class="h-12 w-auto object-contain brightness-0 invert mx-auto" alt="<?= htmlspecialchars($global_company['company_name']) ?>">
                <?php else: ?>
                    <h1 class="text-xl font-bold text-white tracking-tight text-center"><?= htmlspecialchars($global_company['company_name'] ?? 'SÓ AR BH') ?></h1>
                <?php endif; ?>
            </div>
            <nav class="mt-4 px-4 space-y-2">
                <?php if (\App\Services\PermissionService::has('dashboard.view')): ?>
                <a href="/dashboard" class="flex items-center px-4 py-3 text-slate-300 hover:bg-slate-700 hover:text-white rounded-xl transition-all group">
                    <i class="fa-solid fa-chart-line mr-3 text-slate-500 group-hover:text-blue-400"></i>
                    Dashboard
                </a>
                <?php endif; ?>

                <?php if (\App\Services\PermissionService::has('clientes.manage')): ?>
                <a href="/clientes" class="flex items-center px-4 py-3 text-slate-300 hover:bg-slate-700 hover:text-white rounded-xl transition-all group">
                    <i class="fa-solid fa-users mr-3 text-slate-500 group-hover:text-blue-400"></i>
                    Clientes
                </a>
                <?php endif; ?>

                <?php if (\App\Services\PermissionService::has('orcamentos.manage')): ?>
                <a href="/orcamentos" class="flex items-center px-4 py-3 text-slate-300 hover:bg-slate-700 hover:text-white rounded-xl transition-all group">
                    <i class="fa-solid fa-file-invoice-dollar mr-3 text-slate-500 group-hover:text-blue-400"></i>
                    Orçamentos
                </a>
                <?php endif; ?>

                <?php if (\App\Services\PermissionService::has('contratos.manage')): ?>
                <a href="/contratos" class="flex items-center px-4 py-3 text-slate-300 hover:bg-slate-700 hover:text-white rounded-xl transition-all group">
                    <i class="fa-solid fa-file-contract mr-3 text-slate-500 group-hover:text-blue-400"></i>
                    Contratos
                </a>
                <?php endif; ?>

                <?php if (\App\Services\PermissionService::has('financeiro.manage')): ?>
                <a href="/pedidos" class="flex items-center px-4 py-3 text-slate-300 hover:bg-slate-700 hover:text-white rounded-xl transition-all group">
                    <i class="fa-solid fa-truck-front mr-3 text-slate-500 group-hover:text-blue-400"></i>
                    Pedidos
                </a>
                <?php endif; ?>

                <?php if (\App\Services\PermissionService::has('financeiro.manage')): ?>
                <a href="/financeiro" class="flex items-center px-4 py-3 text-slate-300 hover:bg-slate-700 hover:text-white rounded-xl transition-all group">
                    <i class="fa-solid fa-wallet mr-3 text-slate-500 group-hover:text-blue-400"></i>
                    Financeiro
                </a>
                <?php endif; ?>

                <?php if (\App\Services\PermissionService::has('usuarios.manage')): ?>
                <a href="/usuarios" class="flex items-center px-4 py-3 text-slate-300 hover:bg-slate-700 hover:text-white rounded-xl transition-all group">
                    <i class="fa-solid fa-user-shield mr-3 text-slate-500 group-hover:text-blue-400"></i>
                    Equipe
                </a>
                <a href="/roles" class="flex items-center px-4 py-3 text-slate-300 hover:bg-slate-700 hover:text-white rounded-xl transition-all group">
                    <i class="fa-solid fa-shield-halved mr-3 text-slate-500 group-hover:text-blue-400"></i>
                    Níveis de Acesso
                </a>
                <?php endif; ?>

                <?php if (\App\Services\PermissionService::has('configuracoes.manage')): ?>
                <a href="/configuracoes" class="flex items-center px-4 py-3 text-slate-300 hover:bg-slate-700 hover:text-white rounded-xl transition-all group">
                    <i class="fa-solid fa-gear mr-3 text-slate-500 group-hover:text-blue-400"></i>
                    Configurações
                </a>
                <?php endif; ?>
                <div class="pt-4 border-t border-slate-700 mt-4">
                    <a href="/logout" class="flex items-center px-4 py-3 text-red-400 hover:bg-red-500/10 rounded-xl transition-all">
                        <i class="fa-solid fa-right-from-bracket mr-3"></i>
                        Sair
                    </a>
                </div>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="flex-1 p-8 overflow-y-auto">
            <header class="flex justify-between items-center mb-8">
                <h2 class="text-2xl font-bold text-white"><?= $title ?? 'Painel' ?></h2>
                <div class="flex items-center space-x-4">
                    <span class="text-slate-400 text-sm">Olá, <strong class="text-white"><?= $_SESSION['user_nome'] ?></strong></span>
                </div>
            </header>
