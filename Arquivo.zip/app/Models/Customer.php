<?php

namespace App\Models;

class Customer extends BaseModel
{
    protected $table = 'clientes';

    public function create($data)
    {
        $stmt = $this->db->prepare("INSERT INTO {$this->table} (nome, email, telefone, cpf_cnpj, endereco, cidade, estado) VALUES (?, ?, ?, ?, ?, ?, ?)");
        return $stmt->execute([
            $data['nome'],
            $data['email'],
            $data['telefone'],
            $data['cpf_cnpj'],
            $data['endereco'],
            $data['cidade'],
            $data['estado']
        ]);
    }

    public function update($id, $data)
    {
        $stmt = $this->db->prepare("UPDATE {$this->table} SET nome = ?, email = ?, telefone = ?, cpf_cnpj = ?, endereco = ?, cidade = ?, estado = ? WHERE id = ?");
        return $stmt->execute([
            $data['nome'],
            $data['email'],
            $data['telefone'],
            $data['cpf_cnpj'],
            $data['endereco'],
            $data['cidade'],
            $data['estado'],
            $id
        ]);
    }
}
